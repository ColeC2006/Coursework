from Project import TaskList


class StyledText(str):
    def line(self):
        return "--------------------"

def menu():
    print(StyledText("To-Do List").line())
    print("1. View Tasks")
    print("2. Add Task")
    print("3. Edit Task")
    print("4. Delete Task")
    print("5. Save Tasks")
    print("6. Exit")

def main(): #Main console that users can
    task_list = TaskList()
    filename = "../tasks.txt"
    task_list.File_Load(filename)

    while True:
        menu()
        choice = input("Enter your choice (1-6): ").strip()

        if choice == '1':
            tasks = task_list.Get_Tasks()
            if tasks:
                print("\nYour Tasks:")
                for i, task in enumerate(tasks, 1):
                    print(f"{i}. {task}")
            else:
                print("No tasks found.")
            print()

        elif choice == '2':
            new_task = input("Enter the new task: ").strip()
            task_list.Add_Task(new_task)
            print("Task added.\n")

        elif choice == '3':
            tasks = task_list.Get_Tasks()
            if not tasks:
                print("No tasks to edit.\n")
                continue
            for i, task in enumerate(tasks, 1):
                print(f"{i}. {task}")
            try:
                index = int(input("Enter the task number to edit: ")) - 1
                new_text = input("Enter the new task text: ").strip()
                task_list.Edit_Task(index, new_text)
                print("Task updated.\n")
            except ValueError:
                print("Invalid input. Please enter a number.\n")

        elif choice == '4':
            tasks = task_list.Get_Tasks()
            if not tasks:
                print("No tasks to delete.\n")
                continue
            for i, task in enumerate(tasks, 1):
                print(f"{i}. {task}")
            try:
                index = int(input("Enter the task number to delete: ")) - 1
                task_list.Delete_Task(index)
                print("Task deleted.\n")
            except ValueError:
                print("Invalid input. Please enter a number.\n")

        elif choice == '5':
            task_list.File_Save(filename)
            print("Tasks saved to file.\n")

        elif choice == '6':
            task_list.File_Save(filename)
            print("Goodbye! Tasks saved.\n")
            break

        else:
            print("Invalid choice. Please try again.\n")

if __name__ == "__main__":
    main()