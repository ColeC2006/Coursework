class Task:
    def __init__(self, description):
        self.description = description

class TaskList:
    def __init__(self):
        self.tasks = []

    def Add_Task(self, task_text): #Adds a task
        if task_text:
            self.tasks.append(Task(task_text))

    def Delete_Task(self, index): #Deletes the task the user has selected
        try:
            del self.tasks[index]
        except IndexError:
            pass

    def Edit_Task(self, index, new_text): #Edits a task when user gives a coresponding number
        if new_text:
            try:
                self.tasks[index].description = new_text
            except IndexError:
                pass

    def Get_Tasks(self): #allows user to view the task they
        if not self.tasks:
            print("No tasks available.")
        else:
            print("Current Tasks:")
            for i, task in enumerate(self.tasks, 1):
                print(f"{i}. {task.description}")


    def File_Load(self, filename):
        try:
            with open(filename, 'r') as file:
                lines = file.readlines()
                self.tasks = [Task(line.strip()) for line in lines]
        except FileNotFoundError:
            self.tasks = []